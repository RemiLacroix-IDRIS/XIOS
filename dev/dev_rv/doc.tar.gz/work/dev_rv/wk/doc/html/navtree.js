var NAVTREE =
[
  [ "XMLIOSERVER", "index.html", [
    [ "Liste des classes", "annotated.html", [
      [ "xmlioserver::comm::CBuffer::buffer_data", "structxmlioserver_1_1comm_1_1_c_buffer_1_1buffer__data.html", null ],
      [ "xmlioserver::CArrayUtil", "classxmlioserver_1_1_c_array_util.html", null ],
      [ "xmlioserver::tree::CAttribute", "classxmlioserver_1_1tree_1_1_c_attribute.html", null ],
      [ "xmlioserver::tree::CAttributeMap", "classxmlioserver_1_1tree_1_1_c_attribute_map.html", null ],
      [ "xmlioserver::tree::CAttributeTemplate< ValueType >", "classxmlioserver_1_1tree_1_1_c_attribute_template.html", null ],
      [ "xmlioserver::comm::CBuffer", "classxmlioserver_1_1comm_1_1_c_buffer.html", null ],
      [ "xmlioserver::comm::CCircularBuffer", "classxmlioserver_1_1comm_1_1_c_circular_buffer.html", null ],
      [ "xmlioserver::CException", "classxmlioserver_1_1_c_exception.html", null ],
      [ "xmlioserver::CGroupTemplate< U, V, W >", "classxmlioserver_1_1_c_group_template.html", null ],
      [ "xmlioserver::io::CINetCDF4", "classxmlioserver_1_1io_1_1_c_i_net_c_d_f4.html", null ],
      [ "xmlioserver::io::CINetCDF4Adv", "classxmlioserver_1_1io_1_1_c_i_net_c_d_f4_adv.html", null ],
      [ "xmlioserver::comm::CLinearBuffer", "classxmlioserver_1_1comm_1_1_c_linear_buffer.html", null ],
      [ "xmlioserver::comm::CMPIManager", "classxmlioserver_1_1comm_1_1_c_m_p_i_manager.html", null ],
      [ "xmlioserver::CObject", "classxmlioserver_1_1_c_object.html", null ],
      [ "xmlioserver::CObjectTemplate< T >", "classxmlioserver_1_1_c_object_template.html", null ],
      [ "xmlioserver::io::CONetCDF4", "classxmlioserver_1_1io_1_1_c_o_net_c_d_f4.html", null ],
      [ "xmlioserver::CStringUtil", "classxmlioserver_1_1_c_string_util.html", null ],
      [ "xmlioserver::xml::CXMLNode", "classxmlioserver_1_1xml_1_1_c_x_m_l_node.html", null ],
      [ "xmlioserver::xml::CXMLParser", "classxmlioserver_1_1xml_1_1_c_x_m_l_parser.html", null ],
      [ "xmlioserver::CGroupTemplate< U, V, W >::group_refatt", "classxmlioserver_1_1_c_group_template_1_1group__refatt.html", null ],
      [ "xmlioserver::vtk::vtkLSCEReader", "classxmlioserver_1_1vtk_1_1vtk_l_s_c_e_reader.html", null ]
    ] ],
    [ "Index des classes", "classes.html", null ],
    [ "Hiérarchie des classes", "hierarchy.html", [
      [ "xmlioserver::comm::CBuffer::buffer_data", "structxmlioserver_1_1comm_1_1_c_buffer_1_1buffer__data.html", null ],
      [ "xmlioserver::CArrayUtil", "classxmlioserver_1_1_c_array_util.html", null ],
      [ "xmlioserver::tree::CAttributeMap", "classxmlioserver_1_1tree_1_1_c_attribute_map.html", [
        [ "xmlioserver::CObjectTemplate< V >", "classxmlioserver_1_1_c_object_template.html", [
          [ "xmlioserver::CGroupTemplate< U, V, W >", "classxmlioserver_1_1_c_group_template.html", null ]
        ] ],
        [ "xmlioserver::CObjectTemplate< T >", "classxmlioserver_1_1_c_object_template.html", null ]
      ] ],
      [ "xmlioserver::comm::CBuffer", "classxmlioserver_1_1comm_1_1_c_buffer.html", [
        [ "xmlioserver::comm::CCircularBuffer", "classxmlioserver_1_1comm_1_1_c_circular_buffer.html", null ],
        [ "xmlioserver::comm::CLinearBuffer", "classxmlioserver_1_1comm_1_1_c_linear_buffer.html", null ]
      ] ],
      [ "xmlioserver::io::CINetCDF4", "classxmlioserver_1_1io_1_1_c_i_net_c_d_f4.html", [
        [ "xmlioserver::io::CINetCDF4Adv", "classxmlioserver_1_1io_1_1_c_i_net_c_d_f4_adv.html", null ]
      ] ],
      [ "xmlioserver::comm::CMPIManager", "classxmlioserver_1_1comm_1_1_c_m_p_i_manager.html", null ],
      [ "xmlioserver::CObject", "classxmlioserver_1_1_c_object.html", [
        [ "xmlioserver::CObjectTemplate< V >", "classxmlioserver_1_1_c_object_template.html", null ],
        [ "xmlioserver::CException", "classxmlioserver_1_1_c_exception.html", null ],
        [ "xmlioserver::CObjectTemplate< T >", "classxmlioserver_1_1_c_object_template.html", null ],
        [ "xmlioserver::tree::CAttribute", "classxmlioserver_1_1tree_1_1_c_attribute.html", [
          [ "xmlioserver::tree::CAttributeTemplate< ValueType >", "classxmlioserver_1_1tree_1_1_c_attribute_template.html", null ]
        ] ]
      ] ],
      [ "xmlioserver::io::CONetCDF4", "classxmlioserver_1_1io_1_1_c_o_net_c_d_f4.html", null ],
      [ "xmlioserver::CStringUtil", "classxmlioserver_1_1_c_string_util.html", null ],
      [ "xmlioserver::xml::CXMLNode", "classxmlioserver_1_1xml_1_1_c_x_m_l_node.html", null ],
      [ "xmlioserver::xml::CXMLParser", "classxmlioserver_1_1xml_1_1_c_x_m_l_parser.html", null ],
      [ "xmlioserver::CGroupTemplate< U, V, W >::group_refatt", "classxmlioserver_1_1_c_group_template_1_1group__refatt.html", null ],
      [ "xmlioserver::vtk::vtkLSCEReader", "classxmlioserver_1_1vtk_1_1vtk_l_s_c_e_reader.html", null ]
    ] ],
    [ "Membres de classe", "functions.html", null ],
    [ "Liste des espaces de nommage", "namespaces.html", [
      [ "xmlioserver", "namespacexmlioserver.html", null ],
      [ "xmlioserver::comm", "namespacexmlioserver_1_1comm.html", null ],
      [ "xmlioserver::io", "namespacexmlioserver_1_1io.html", null ],
      [ "xmlioserver::tree", "namespacexmlioserver_1_1tree.html", null ],
      [ "xmlioserver::vtk", "namespacexmlioserver_1_1vtk.html", null ],
      [ "xmlioserver::xml", "namespacexmlioserver_1_1xml.html", null ]
    ] ],
    [ "Membres de l'espace de nommage", "namespacemembers.html", null ],
    [ "Liste des fichiers", "files.html", [
      [ "src4/xmlio/array_util.hpp", "array__util_8hpp.html", null ],
      [ "src4/xmlio/array_util_impl.hpp", "array__util__impl_8hpp.html", null ],
      [ "src4/xmlio/declare_attribute.hpp", "declare__attribute_8hpp.html", null ],
      [ "src4/xmlio/exception.cpp", "exception_8cpp.html", null ],
      [ "src4/xmlio/exception.hpp", "exception_8hpp.html", null ],
      [ "src4/xmlio/exception_mac.hpp", "exception__mac_8hpp.html", null ],
      [ "src4/xmlio/group_template.hpp", "group__template_8hpp.html", null ],
      [ "src4/xmlio/group_template_impl.hpp", "group__template__impl_8hpp.html", null ],
      [ "src4/xmlio/main_server.cpp", "main__server_8cpp.html", null ],
      [ "src4/xmlio/object.cpp", "object_8cpp.html", null ],
      [ "src4/xmlio/object.hpp", "object_8hpp.html", null ],
      [ "src4/xmlio/object_template.hpp", "object__template_8hpp.html", null ],
      [ "src4/xmlio/object_template_impl.hpp", "object__template__impl_8hpp.html", null ],
      [ "src4/xmlio/string_util.hpp", "string__util_8hpp.html", null ],
      [ "src4/xmlio/xmlioserver.hpp", "xmlioserver_8hpp.html", null ],
      [ "src4/xmlio/xmlioserver_spl.hpp", "xmlioserver__spl_8hpp.html", null ],
      [ "src4/xmlio/attribute/attribute.cpp", "attribute_8cpp.html", null ],
      [ "src4/xmlio/attribute/attribute.hpp", "attribute_8hpp.html", null ],
      [ "src4/xmlio/attribute/attribute_impl.hpp", "attribute__impl_8hpp.html", null ],
      [ "src4/xmlio/attribute/attribute_map.cpp", "attribute__map_8cpp.html", null ],
      [ "src4/xmlio/attribute/attribute_map.hpp", "attribute__map_8hpp.html", null ],
      [ "src4/xmlio/attribute/attribute_template.cpp", "attribute__template_8cpp.html", null ],
      [ "src4/xmlio/attribute/attribute_template.hpp", "attribute__template_8hpp.html", null ],
      [ "src4/xmlio/attribute/attribute_template_impl.hpp", "attribute__template__impl_8hpp.html", null ],
      [ "src4/xmlio/buffer/buffer.cpp", "buffer_8cpp.html", null ],
      [ "src4/xmlio/buffer/buffer.hpp", "buffer_8hpp.html", null ],
      [ "src4/xmlio/buffer/buffer_impl.hpp", "buffer__impl_8hpp.html", null ],
      [ "src4/xmlio/buffer/circular_buffer.cpp", "circular__buffer_8cpp.html", null ],
      [ "src4/xmlio/buffer/circular_buffer.hpp", "circular__buffer_8hpp.html", null ],
      [ "src4/xmlio/buffer/linear_buffer.hpp", "linear__buffer_8hpp.html", null ],
      [ "src4/xmlio/config/node_type.conf", "node__type_8conf.html", null ],
      [ "src4/xmlio/fortran/icaxis.cpp", "icaxis_8cpp.html", null ],
      [ "src4/xmlio/fortran/iccontext.cpp", "iccontext_8cpp.html", null ],
      [ "src4/xmlio/fortran/icdata.cpp", "icdata_8cpp.html", null ],
      [ "src4/xmlio/fortran/icdate.cpp", "icdate_8cpp.html", null ],
      [ "src4/xmlio/fortran/icdomain.cpp", "icdomain_8cpp.html", null ],
      [ "src4/xmlio/fortran/icfield.cpp", "icfield_8cpp.html", null ],
      [ "src4/xmlio/fortran/icfile.cpp", "icfile_8cpp.html", null ],
      [ "src4/xmlio/fortran/icgrid.cpp", "icgrid_8cpp.html", null ],
      [ "src4/xmlio/fortran/icutil.hpp", "icutil_8hpp.html", null ],
      [ "src4/xmlio/fortran/icxml_tree.cpp", "icxml__tree_8cpp.html", null ],
      [ "src4/xmlio/mpi/mpi_interface.cpp", "mpi__interface_8cpp.html", null ],
      [ "src4/xmlio/mpi/mpi_interface.hpp", "mpi__interface_8hpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4.cpp", "inetcdf4_8cpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4.hpp", "inetcdf4_8hpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4_adv.cpp", "inetcdf4__adv_8cpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4_adv.hpp", "inetcdf4__adv_8hpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4_adv_impl.hpp", "inetcdf4__adv__impl_8hpp.html", null ],
      [ "src4/xmlio/netcdf/inetcdf4_impl.hpp", "inetcdf4__impl_8hpp.html", null ],
      [ "src4/xmlio/netcdf/onetcdf4.cpp", "onetcdf4_8cpp.html", null ],
      [ "src4/xmlio/netcdf/onetcdf4.hpp", "onetcdf4_8hpp.html", null ],
      [ "src4/xmlio/netcdf/onetcdf4_impl.hpp", "onetcdf4__impl_8hpp.html", null ],
      [ "src4/xmlio/node/node_enum.hpp", "node__enum_8hpp.html", null ],
      [ "src4/xmlio/vtk/lscereader.cpp", "lscereader_8cpp.html", null ],
      [ "src4/xmlio/vtk/lscereader.hpp", "lscereader_8hpp.html", null ],
      [ "src4/xmlio/xml/xml_node.cpp", "xml__node_8cpp.html", null ],
      [ "src4/xmlio/xml/xml_node.hpp", "xml__node_8hpp.html", null ],
      [ "src4/xmlio/xml/xml_parser.cpp", "xml__parser_8cpp.html", null ],
      [ "src4/xmlio/xml/xml_parser.hpp", "xml__parser_8hpp.html", null ]
    ] ],
    [ "Répertoires", "dirs.html", [
      [ "src4", "dir_b03c9937c951bdb3aa633ccbe7b9c2a7.html", [
        [ "xmlio", "dir_3fa3c96ad9c274e2e29a05f8c25504cb.html", [
          [ "attribute", "dir_92ce1e99c72c5bbb7058be294d37ba03.html", null ],
          [ "buffer", "dir_d96beeacace62f2349b3a6cc7885bc64.html", null ],
          [ "config", "dir_8799ac905c2d659c33292a82889b7f5e.html", null ],
          [ "fortran", "dir_15e5079bed98afa94690be9b1e9f13f4.html", null ],
          [ "mpi", "dir_b93bc6fa38e07c2ace7f5e38caa18e8a.html", null ],
          [ "netcdf", "dir_183df131eb71024a0f311d663322fde9.html", null ],
          [ "node", "dir_5073cc331fc58ac2453ea80b756845bc.html", null ],
          [ "vtk", "dir_e987723ec88ec7e84a9698083f596409.html", null ],
          [ "xml", "dir_e95d6e70a44a2d49e73277fa04227921.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Membres de fichier", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

